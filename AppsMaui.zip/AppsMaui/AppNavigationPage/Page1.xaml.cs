namespace AppNavigationPage;

public partial class Page1 : ContentPage
{
	public Page1()
	{
		InitializeComponent();
	}

	private void Button_Next(object sender, EventArgs e)
	{
		Navigation.PushAsync(new Page2());
	}
}