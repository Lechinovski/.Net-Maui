namespace AppFlyoutPage;

public partial class FlyoutPageMenu : FlyoutPage
{
	public FlyoutPageMenu()
	{
		InitializeComponent();
	}
}