namespace AppContentPage;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}
}